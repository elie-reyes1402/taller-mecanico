# Web taller mecanico maqueen
Implementaciones con jquery y validaciones.

```
Index:
* Se implemento un carrucel con jqueri para la movilidad y para que fuera responsive.
```
```
Registro:
* Se valido el campo usuario y el nombre para que aceptara diferentes caracteres.
* Se valido el campo contraseña para que solo aceptara de 4 a 16 digitos y la contraseña secundaria para ambas fueran iguales.
* Se valido el campo correo para que solo fuera correcto con un @ y .com/.cl  y aceptara una gran variedad de caracteres. 
* Se valido el campo telefono para que solo aceptara numeros y solo de 7 a 12 numeros.
* Se valido el ingresar para que solo se pudiera enviar en caso que todos los campos fueran completados y aceptara los terminos y  condiciones.
* Tambien se agrego el comando acronym para que al momento de pasar el maus sobre un campo especifique la accion a realizar.
```

```
Contacto:
* Se valido el campo correo para que solo fuera correcto con un @ y .com/.cl  y aceptara una gran variedad de caracteres. 
* Se valido el ingresar para que solo se pudiera enviar en caso que todos los campos fueran completados de manera correcta.
* Tambien se agrego el comando acronym para que al momento de pasar el maus sobre un campo especifique la accion a realizar.
```